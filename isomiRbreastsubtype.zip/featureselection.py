import math
import time
import numpy as np
import copy
from scipy.stats import pearsonr


def loadDataSet(fileName, delim='\t'):
    fr = open(fileName,"r")
    stringArr = [line.strip().split(delim) for line in fr.readlines()]
    print "end read"
    #datArr = [map(float,line) for line in stringArr]
    return stringArr

def writeDict(thedict,filename):
    fw = open(filename,"w")
    try:
        for i in thedict.keys():
            fw.writelines(i+"\t")
            fw.writelines(str(thedict[i])+"\n")
    finally:
        fw.close()

def writelist(thelist,filename):
    fw = open(filename,"w")
    try:
        fw.writelines("Name"+"\t"+"Weight"+"\n")
        for i in thelist:
            fw.writelines(str(i[0])+"\t"+str(i[1])+"\n")
    finally:
        fw.close()

def writenumberlist(thelist,filename):
    fw = open(filename,"w")
    try:
##        fw.writelines("Name"+"\t"+"InformationGain"+"\n")
        for i in thelist:
            fw.writelines(str(i[1])+"\n")
    finally:
        fw.close()

def wirteinterlist(thelist,filename):
    fw = open(filename,"w")
    try:
        fw.writelines("Name"+"\t"+"min"+"\t"+"max"+"\n")
        for i in thelist:
            fw.writelines(str(i[0])+"\t"+str(i[1])+"\t"+str(i[2])+"\n")
    finally:
        fw.close()


def calculateweight():
    strlabel = "1"
    clusterlabeladdr = "dataset/numlabel.txt"
    inputdataaddr = "dataset/finaldata.txt"
    clusterlabellist = loadDataSet(clusterlabeladdr)
    inputdatalist = loadDataSet(inputdataaddr)
    inputdatalist2 = copy.deepcopy(inputdatalist)
    clusterdict = getclusterdict(clusterlabellist)
    weightdict = calculatemutual(clusterdict,inputdatalist)
    sortedfinaldict = sorted(weightdict.iteritems(),key=lambda x:x[1],reverse = True)
    writelist(sortedfinaldict,"Biomarker.txt")

def calculatemutual(clusterdict,inputdatalist):
    retdict = {}
    curr = 0
    totalvalue = len(inputdatalist)
    for oneline in inputdatalist:
        curr = curr+1
        print str(curr)+"/"+str(totalvalue)
        isoname = oneline[0]
        middlelist = oneline
        del middlelist[0]
        expdict = getexpressdict(middlelist, clusterdict)
        retdict[isoname] = calculateMutualvalue(expdict)
    return retdict


def normalexplist(explist):
    retlist = []
    middlelist = [float(var) for var in explist]
    maxvalue = max(middlelist)
    minvalue = min(middlelist)
    intervalue = maxvalue-minvalue
    retlist = [(float(var)-minvalue)/intervalue for var in explist]
    
    return retlist


def calculateMutualvalue(expdict):
    retvalue = 0.0
    variblelist = []
    labellist = []
    for label in expdict.keys():
        middlelist = expdict[label]
        middlelabellist = [float(label)]*len(middlelist)
        variblelist = variblelist+middlelist
        labellist = labellist+middlelabellist
    
    variblelist = normalexplist(variblelist)
    totalvalue = 0.0
    for i in range(0,len(variblelist)):
        xi = variblelist[i]
        yi = labellist[i]
        fxi = calculatefx(xi,variblelist)
        fyi = calculatefy(yi,labellist)
        fxiyi = calculatefxy(xi,yi,variblelist,labellist)
        middlevalue = fxiyi/(fxi*fyi)
        totalvalue = totalvalue+math.log(middlevalue,2)
    retvalue = totalvalue/float(len(variblelist))
    return retvalue
    

def calculatefy(yi,thelist):
    retvalue = 0.0
    thelen = float(len(thelist))
    leftvalue = 1.0/(thelen*math.sqrt(2*math.pi))
    totalvalue = 0.0
    for i in thelist:
        if float(i)==float(yi):
            upvalue = 0
        else:
            upvalue = -0.5
        totalvalue = totalvalue+math.exp(upvalue)
    totalvalue = leftvalue*totalvalue
    return totalvalue


def calculatefx(xi,thelist):
    retvalue = 0.0
    thelen = float(len(thelist))
    leftvalue = 1.0/(thelen*math.sqrt(2*math.pi))
    totalvalue = 0.0
    for i in thelist: 
        upvalue = -((xi-i)**2)/2
        totalvalue = totalvalue+math.exp(upvalue)
    totalvalue = leftvalue*totalvalue
    return totalvalue

def calculatefxy(xi,yi,variblelist,labellist):
    retvalue = 0.0
    thelen = float(len(variblelist))
    leftvalue = 1.0/(thelen*2*math.pi)
    totalvalue = 0.0
    for k in range(0,int(thelen)):
        xk = variblelist[k]
        yk = labellist[k]
        upvalue = -calculatedk(xi,yi,xk,yk)/2
        totalvalue = totalvalue+math.exp(upvalue)
    revalue = leftvalue*totalvalue
    return revalue
        
        
    
def calculatedk(xi,yi,xk,yk):
##    retvalue = 0.0
    rightvalue = 0.0
    if float(yi)==float(yk):
        rightvalue = 0.0
    else:
        rightvalue = 1.0
    retvalue = (xi-xk)**2+rightvalue**2
    return retvalue

def getexpressdict(middlelist, clusterdict):
    retdict = {}
    for clustername in clusterdict.keys():
        indexlist = clusterdict[clustername]
        retdict[clustername] = []
        for i in indexlist:
            retdict[clustername].append(middlelist[i])
    return retdict



def calculateWeight(clusterdict, inputdatalist):
    retdict = {}
    k = 0
    for line in inputdatalist:
        k = k+1
        print k
        isomiRname = line[0]
        del line[0]
        retdict[isomiRname] = calculateJdistance(clusterdict, line)
    return retdict



def getclusterdict(clusterdatalist):
    retdict = {}
    thesamplelabel = 0
    for middlelist in clusterdatalist:
        theclusterlabel = middlelist[0]
        if theclusterlabel not in retdict.keys():
            retdict[theclusterlabel] = []
        retdict[theclusterlabel].append(thesamplelabel)
        thesamplelabel = thesamplelabel+1
##    retdict{ "cluster1(1)":[sample1,sample2...],"cluster2(2)":[sample3,sample4...]...  }
    return retdict




if __name__=="__main__":
    calculateweight()
