The file featureselection.py is the program of calculating the weight of the isomiR for breast cancer subtype classification by using improved mutual information.

The input files are:
	1  dataset/finaldata.txt
	2  dataset/numlabel.txt

	dataset/finaldata.txt: is the expression level of isomiRs in all the samples. The first column of this file is the name of isomiR, the second column is the expression level of isomiR in the first sample(patient)... the Nth column is the expression level of isomiRs in the (N-1)th patient.
	
	dataset/numlabel.txt: is the breast cancer subtype of the sample. The Nth line is the label of the breast cancer subtype of Nth sample(patient). The label of breast cancer subtype are showed below:
	
				label number	breast cancer subtype	
					1				ER+HER2-
					2			    ER-HER2+
					3			  Triple negative
					4			    ER+HER2+
		 
The output file is 
	Biomarker.txt
	
	This file output the weight of the isomiR for breast cacner subtype classification. The larger the weight, the more important the isomiR for the breast cancer subtype classification.

Run the file:
Python featureselection.py	
	